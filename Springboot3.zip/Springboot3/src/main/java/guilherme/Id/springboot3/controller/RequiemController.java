package guilherme.Id.springboot3.controller;

import guilherme.Id.springboot3.domain.Requiem;
import guilherme.Id.springboot3.util.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("requiem")
@Log4j2
@RequiredArgsConstructor
public class RequiemController {
    private final DateUtil dateUtil;

    //localhost:8080/requiem/list
    @GetMapping(path = "list")
    public List<Requiem> list(){
        log.info(dateUtil.formatLocalDateTimeToDatabaseStyle(LocalDateTime.now()));
        return List.of(new Requiem( "Berserk"), new Requiem("SAO")); }
}
