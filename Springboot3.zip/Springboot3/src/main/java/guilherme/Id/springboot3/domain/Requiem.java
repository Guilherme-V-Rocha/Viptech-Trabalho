package guilherme.Id.springboot3.domain;

public class Requiem {
    private String name;

    public Requiem(String name){
        this.name = name;
    }
    public Requiem() {
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
